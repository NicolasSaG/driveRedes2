
/**
 *
 * @author fnico
 */
public class Main {
    public static void main(String[] args) {
        NodoCentral nc = new NodoCentral();
        nc.init();
    }
}
